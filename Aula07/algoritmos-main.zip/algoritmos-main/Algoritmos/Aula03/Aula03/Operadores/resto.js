let numero1 = 10;
let numero2 = 2;
const resto = numero1 % numero2

console.log(resto);