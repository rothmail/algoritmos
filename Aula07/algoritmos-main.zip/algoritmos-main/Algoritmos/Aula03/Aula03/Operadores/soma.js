let numero1 = 60;
let numero2 = 35;
const soma = numero1 + numero2;

console.log(soma);