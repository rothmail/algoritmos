let numero1 = 9;
let numero2 = 6;
const multiplicacao = numero1 * numero2

console.log(multiplicacao);