let numero1 = 12;
let numero2 = 6;
const divisao = numero1 / numero2;

console.log(numero1/numero2);