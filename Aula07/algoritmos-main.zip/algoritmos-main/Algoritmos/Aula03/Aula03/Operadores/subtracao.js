let numero1 = 9;
let numero2 = 6;

const subtracao = numero1 - numero2;
console.log(subtracao);