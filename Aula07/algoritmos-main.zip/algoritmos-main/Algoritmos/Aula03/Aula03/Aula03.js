// Este código imprime uma mensagem
// console.log('Eu sou Amanda');
/*
const nome = 'Amanda';
const idade = 15;

console.log('Olá, eu sou', nome,'e tenho', idade, 'anos,', 
'tudo bem?');

* multiplica, / divide

const altura = 1.6;
const temperatura = 27;
console.log(temperatura / 3, altura * 2);

let souUmBoolean = true;
souUmBoolean = false;
console.log(souUmBoolean);
*/
/*
const nome = 'Amanda';
const sobrenome = 'Rothmann';
const idade = 15;
let estudante = true;

console.log('Meu nome é', nome, sobrenome, 'e tenho', idade, 'anos', estudante)
*/
/*
const serie = 'game of thrones';
const temporadas = 8;

console.log(serie, 'é do tipo', typeof serie, 'e tem', temporadas, 'temperadas e esta quantidade é do tipo', typeof temporadas);
*/
/*
const idadeNumero = 15
const idadeTexto = idadeNumero.toString();

console.log(typeof idadeNumero);
console.log(typeof idadeTexto);

const idadeTexto2 = '15';
const idadeNumero2 = Number(idadeTexto);

console.log(typeof idadeTexto2);
console.log(typeof idadeNumero2);
*/

const numero1 = '5';
const numero2 = '2';

console.log(Number(numero1)/Number(numero2));