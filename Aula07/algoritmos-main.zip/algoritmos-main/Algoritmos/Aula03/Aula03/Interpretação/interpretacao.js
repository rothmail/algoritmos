// Interpretação
1 -  10, 5
2 - 10, 10, 10