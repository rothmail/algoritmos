const var1 = 50;
const var2 = 35;

// === = Igual
console.log(var1 ===(2*25)); // true
console.log(var1 === 50); //true
console.log(var1 === var2); //false

// !== = diferente
console.log(var1 !== var2); // true

// >
console.log(var1 > var2); // true

// maior ou igual >=
console.log(var1 >= var2); // true

// menor <
console.log(var1 < var2); // false

// menor ou igual <=
console.log(var1 <= var2); // false