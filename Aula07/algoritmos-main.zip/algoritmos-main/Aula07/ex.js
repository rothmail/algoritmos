let ensinoMedio = true;
let maiorIdade = 18;
let idade = 17 >= maiorIdade;
let cursando = false;

if (idade&& ensinoMedio && cursando) {
    console.log('Sim');
} else {
    console.log('Não');
}