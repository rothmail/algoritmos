const idade = 15;

if (idade >= 18) {
    console.log('Pode dirigir')
} else {
    console.log('Não pode dirigir')
}

let turno = 'Manhã';
let turno2 = 'Tarde';
let turno3 = 'Noite';

if (turno) {
    console.log('Bom dia')
} else if (turno2){
    console.log('Boa tarde')
} else {
    console.log('Boa noite')
}